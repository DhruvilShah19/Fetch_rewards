//
//  MealDetail.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/31/24.
//

import Foundation

struct MealDetailResponse: Codable {
    let meals: [MealDetail]
}

struct MealDetail: Codable, Identifiable {
    var id: String { idMeal }
    let idMeal: String
    let strMeal: String
    let strInstructions: String?
    let strMealThumb: String?
    let strArea: String?
    let strIngredient1: String?
    let strIngredient2: String?
    let strIngredient3: String?
    let strIngredient4: String?
    let strIngredient5: String?
    let strIngredient6: String?
    let strIngredient7: String?
    let strIngredient8: String?
    let strIngredient9: String?
    let strIngredient10: String?
    let strIngredient11: String?
    let strIngredient12: String?
    let strIngredient13: String?
    let strIngredient14: String?
    let strIngredient15: String?
    let strIngredient16: String?
    let strIngredient17: String?
    let strIngredient18: String?
    let strIngredient19: String?
    let strIngredient20: String?
    
    let strMeasure1: String?
    let strMeasure2: String?
    let strMeasure3: String?
    let strMeasure4: String?
    let strMeasure5: String?
    let strMeasure6: String?
    let strMeasure7: String?
    let strMeasure8: String?
    let strMeasure9: String?
    let strMeasure10: String?
    let strMeasure11: String?
    let strMeasure12: String?
    let strMeasure13: String?
    let strMeasure14: String?
    let strMeasure15: String?
    let strMeasure16: String?
    let strMeasure17: String?
    let strMeasure18: String?
    let strMeasure19: String?
    let strMeasure20: String?
    
    
    var ingredients: [String] {
        var ingredientsList = [String]()
        
        if let ingredient1 = strIngredient1, !ingredient1.isEmpty, let measure1 = strMeasure1 { ingredientsList.append("\(ingredient1): \(measure1)") }
        if let ingredient2 = strIngredient2, !ingredient2.isEmpty, let measure2 = strMeasure2 { ingredientsList.append("\(ingredient2): \(measure2)") }
        if let ingredient3 = strIngredient3, !ingredient3.isEmpty, let measure3 = strMeasure3 { ingredientsList.append("\(ingredient3): \(measure3)") }
        if let ingredient4 = strIngredient4, !ingredient4.isEmpty, let measure4 = strMeasure4 { ingredientsList.append("\(ingredient4): \(measure4)") }
        if let ingredient5 = strIngredient5, !ingredient5.isEmpty, let measure5 = strMeasure5 { ingredientsList.append("\(ingredient5): \(measure5)") }
        if let ingredient6 = strIngredient6, !ingredient6.isEmpty, let measure6 = strMeasure6 { ingredientsList.append("\(ingredient6): \(measure6)") }
        if let ingredient7 = strIngredient7, !ingredient7.isEmpty, let measure7 = strMeasure7 { ingredientsList.append("\(ingredient7): \(measure7)") }
        if let ingredient8 = strIngredient8, !ingredient8.isEmpty, let measure8 = strMeasure8 { ingredientsList.append("\(ingredient8): \(measure8)") }
        if let ingredient9 = strIngredient9, !ingredient9.isEmpty, let measure9 = strMeasure9 { ingredientsList.append("\(ingredient9): \(measure9)") }
        if let ingredient10 = strIngredient10, !ingredient10.isEmpty, let measure10 = strMeasure10 { ingredientsList.append("\(ingredient10): \(measure10)") }
        if let ingredient11 = strIngredient11, !ingredient11.isEmpty, let measure11 = strMeasure11 { ingredientsList.append("\(ingredient11): \(measure11)") }
        if let ingredient12 = strIngredient12, !ingredient12.isEmpty, let measure12 = strMeasure12 { ingredientsList.append("\(ingredient12): \(measure12)") }
        if let ingredient13 = strIngredient13, !ingredient13.isEmpty, let measure13 = strMeasure13 { ingredientsList.append("\(ingredient13): \(measure13)") }
        if let ingredient14 = strIngredient14, !ingredient14.isEmpty, let measure14 = strMeasure14 { ingredientsList.append("\(ingredient14): \(measure14)") }
        if let ingredient15 = strIngredient15, !ingredient15.isEmpty, let measure15 = strMeasure15 { ingredientsList.append("\(ingredient15): \(measure15)") }
        if let ingredient16 = strIngredient16, !ingredient16.isEmpty, let measure16 = strMeasure16 { ingredientsList.append("\(ingredient16): \(measure16)") }
        if let ingredient17 = strIngredient17, !ingredient17.isEmpty, let measure17 = strMeasure17 { ingredientsList.append("\(ingredient17): \(measure17)") }
        if let ingredient18 = strIngredient18, !ingredient18.isEmpty, let measure18 = strMeasure18 { ingredientsList.append("\(ingredient18): \(measure18)") }
        if let ingredient19 = strIngredient19, !ingredient19.isEmpty, let measure19 = strMeasure19 { ingredientsList.append("\(ingredient19): \(measure19)") }
        if let ingredient20 = strIngredient20, !ingredient20.isEmpty, let measure20 = strMeasure20 { ingredientsList.append("\(ingredient20): \(measure20)") }
        return ingredientsList
    }
}

