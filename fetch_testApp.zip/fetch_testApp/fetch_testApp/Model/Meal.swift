//
//  randomMeal.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/30/24.
//

import Foundation

struct MealResponse: Codable {
    let meals: [Meal]
}

struct Meal: Codable, Identifiable {
    var id: String { idMeal }
    let idMeal: String
    let strMeal: String?
    let strArea: String?
    let strMealThumb: String?
    let strTags: String?
}
