//
//  fetch_testAppApp.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/29/24.
//

import SwiftUI

@main
struct fetch_testAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
