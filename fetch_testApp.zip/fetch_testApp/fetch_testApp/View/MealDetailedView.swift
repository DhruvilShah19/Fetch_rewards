//
//  MealDetailedView.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/30/24.
//

import Foundation
import SwiftUI

struct MealDetailView: View {
    let meal: Meal

    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
            }
        }
    }
}
