//
//  HomeView.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/29/24.
//

import SwiftUI

struct HomeView: View {
    @StateObject private var mealsViewModel = MealsViewModel()
    @StateObject private var categoriesViewModel = CategoriesViewModel()
    
    var body: some View {
        VStack(alignment: .leading) {
            if let meal = mealsViewModel.meal {
                MealView(viewModel: mealsViewModel, meal: meal)
            } else if mealsViewModel.isLoading {
                ProgressView()
            } else {
                Text("No meal to display")
            }
            
            Text("List of Categories to try...")
                .font(.headline)
                .padding(.leading)
            
            CategoryView(viewModel: categoriesViewModel)
                .frame(height: 130)
                .padding(.horizontal)

            List(categoriesViewModel.selectedCategoryMeals, id: \.id) { meal in
                NavigationLink(destination: MealDetailView(mealId: meal.idMeal)) {
                    MealRow(meal: meal)
                }
            }
        }
        .onAppear {
            mealsViewModel.fetchRandomMeal()
            categoriesViewModel.fetchCategories()
            categoriesViewModel.selectCategory(categoriesViewModel.selectedCategory)
        }
    }
}

