import SwiftUI

struct ProfileView: View {
    let profileImage = "person.crop.circle.fill"
    let name = "Dhruvil Shah"
    let email = "dhruvilshah800@gmail.com"
    let bio = "A dummy Page to showcase my iOS Skills for interview purpose only."
    let aboutComponents = [
        "The Application Showcases all the details asked by the company. I have used 4 APIs in total",
        "1. Fetch Random Meal (For a good starting point of Application)",
        "2. List of Categories (It will Fetch all the Categories on UI in Horizontal stack, By Defualt: Dessert)",
        "3. List of Meals for any Particular Category in Alphabetical order(By Default Meal will be for Dessert category and can be changed by selecting any other category)",
        "4. Meal details including Location, ID, Ingredients, Measurements, and Instructions.",
        "You will find very minimialistic and Intuitive UI with a Teal theme and will support both Dark and Light Environment"
    ]

    var body: some View {
        ScrollView {
            VStack(alignment: .center, spacing: 20) {
                
                Image(systemName: profileImage)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 120)
                    .padding(.top, 40)
                
                Text(name)
                    .font(.title2)
                    .fontWeight(.bold)
                
                Text(email)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                infoCard(title: "Bio", content: bio)
                
                infoCard(title: "About the App", content: aboutComponents)
                
                Spacer()
            }
            .padding()
            .navigationBarTitle("", displayMode: .inline)
        }
    }
    
    @ViewBuilder
    private func infoCard(title: String, content: String) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)
                .foregroundColor(.teal)
            
            Text(content)
                .font(.body)
                .foregroundColor(.primary)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color(.systemBackground)).shadow(color: Color.gray.opacity(0.3), radius: 5))
    }
    
    @ViewBuilder
    private func infoCard(title: String, content: [String]) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(title)
                .font(.headline)
                .foregroundColor(.teal)
            
            ForEach(content, id: \.self) { item in
                HStack(alignment: .top) {
                    Text(item)
                        .font(.body)
                        .foregroundColor(.primary)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15).fill(Color(.systemBackground)).shadow(color: Color.gray.opacity(0.3), radius: 5))
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
