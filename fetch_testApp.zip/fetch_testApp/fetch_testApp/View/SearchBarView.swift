//
//  SearchBarView.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/29/24.
//

import Foundation
import SwiftUI

struct SearchBarView: View {
    @Binding var searchText: String
    
    var body: some View {
        HStack {
            TextField("Search...", text: $searchText)
                .padding(10)
                .padding(.horizontal, 25)
                .background(Color(.systemBackground))
                .cornerRadius(10)
                .overlay(
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.teal)
                            .frame(minWidth: 0, maxWidth: .infinity, alignment: .leading)
                            .padding(.leading, 15)
                        
                        if !searchText.isEmpty {
                            Button(action: {
                                withAnimation {
                                    searchText = ""
                                }
                            }) {
                                Image(systemName: "multiply.circle.fill")
                                    .foregroundColor(.teal)
                                    .padding(.trailing, 15)
                            }
                        }
                    }
                )
        }
        .padding(.horizontal).shadow(color: Color.teal,radius: 3)
    }
}
