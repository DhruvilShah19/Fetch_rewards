//
//  CategoriesView.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/29/24.
//

import Foundation
import SwiftUI

struct CategoriesView: View {
    @ObservedObject var viewModel: CategoriesViewModel
    var body: some View {
        Text("Categories Screen")
    }
}
