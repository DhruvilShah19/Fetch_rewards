//
//  CategoryView.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/30/24.
//

import Foundation
import SwiftUI


struct CategoryView: View {
    @ObservedObject var viewModel: CategoriesViewModel

    var body: some View {
        ScrollView(.horizontal, showsIndicators: true) {
            LazyHStack {
                ForEach(viewModel.categories, id: \.id) { category in
                    CategoryRow(category: category, isSelected: category.strCategory == viewModel.selectedCategory) {
                        viewModel.selectCategory(category.strCategory)
                    }
                }
            }
        }
    }
}

struct CategoryRow: View {
    let category: Category
    var isSelected: Bool
    var onCategorySelected: () -> Void

    var body: some View {
        VStack {
            AsyncImage(url: URL(string: category.strCategoryThumb)) { image in
                image.resizable()
            } placeholder: {
                Color.gray
            }
            .frame(width: 80, height: 80)
            .clipShape(Circle())
            .overlay(Circle().stroke(isSelected ? Color.purple : Color.gray, lineWidth: 2))
            .padding(8)
            
            Text(category.strCategory)
                .font(.headline)
                .foregroundColor(isSelected ? .purple : .primary)
        }
        .padding(.horizontal, 10)
        .background(isSelected ? Color.teal.opacity(0.2) : Color.clear)
        .cornerRadius(10)
        .shadow(radius: 2)
        .onTapGesture {
            onCategorySelected()
        }
    }
}

