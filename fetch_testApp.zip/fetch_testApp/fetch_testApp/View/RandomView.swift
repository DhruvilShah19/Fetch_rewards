import Foundation
import SwiftUI

struct MealView: View {
    @ObservedObject var viewModel: MealsViewModel
    let meal: Meal
    
    var body: some View {
        NavigationLink(destination: MealDetailView(mealId: meal.idMeal)) {
            HStack {
                mealImage
                mealDetails
                Spacer()
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
            }
            .padding()
            .background(Color(.systemBackground))
            .cornerRadius(8)
            .shadow(radius: 2)
        }.padding()
    }
    
    private var mealImage: some View {
        AsyncImage(url: URL(string: meal.strMealThumb!)) { phase in
            switch phase {
            case .success(let image):
                image.resizable().aspectRatio(contentMode: .fill)
            case .failure:
                Image(systemName: "photo").aspectRatio(contentMode: .fit)
            case .empty:
                ProgressView()
            @unknown default:
                EmptyView()
            }
        }
        .frame(width: 80, height: 80)
        .cornerRadius(8)
    }
    
    private var mealDetails: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(meal.strMeal!)
                .font(.headline).lineLimit(1)
            HStack {
                Image(systemName: "mappin.and.ellipse")
                    .foregroundColor(.blue)
                Text(meal.strArea!)
                    .font(.subheadline)
                    .lineLimit(1)
            }
            if let tags = meal.strTags {
                HStack {
                    Image(systemName: "tag")
                        .foregroundColor(.green)
                    Text(tags)
                        .font(.caption)
                        .foregroundColor(.gray)
                        .padding(5)
                        .background(Color.yellow.opacity(0.2))
                        .cornerRadius(5)
                }
            }
        }
        .padding(.leading, 8)
    }
}
