import SwiftUI

struct MealDetailView: View {
    @ObservedObject var viewModel: MealDetailViewModel
    let mealId: String
    
    init(mealId: String) {
        self.mealId = mealId
        self.viewModel = MealDetailViewModel()
    }
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                mealImage
                mealLocationAndID
                if let mealDetail = viewModel.mealDetail {
                    ingredientsSection(mealDetail)
                    instructionsSection(mealDetail)
                } else if viewModel.isLoading {
                    ProgressView().scaleEffect(1.5).padding()
                } else if let errorMessage = viewModel.errorMessage {
                    Text("Error: \(errorMessage)").foregroundColor(.red).padding()
                }
                Spacer()
            }
        }
        .onAppear {
            viewModel.fetchMealDetail(byId: mealId)
        }
        .navigationBarTitle("", displayMode: .inline).edgesIgnoringSafeArea(.top)
    }
    
    private var mealImage: some View {
        Group {
            if let imageUrl = viewModel.mealDetail?.strMealThumb, let url = URL(string: imageUrl) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        ProgressView()
                    case .success(let image):
                        image.resizable().scaledToFit()
                    case .failure:
                        Image("placeholder").resizable().scaledToFit()
                    @unknown default:
                        EmptyView()
                    }
                }
            } else {
                Image("placeholder").resizable().scaledToFit()
            }
        }
    }
    
    private var mealLocationAndID: some View {
        Group {
            if let mealDetail = viewModel.mealDetail {
                VStack(alignment: .leading) {
                    Text(mealDetail.strMeal)
                        .font(.title)
                        .fontWeight(.bold)
                        .padding(.vertical, 5)
                    
                    HStack {
                        detailItem(icon: "doc.circle", text: mealDetail.idMeal)
                        detailItem(icon: "mappin.and.ellipse", text: mealDetail.strArea ?? "")
                    }.padding([.top, .trailing, .bottom])
                }.cornerRadius(8)
            }
        }.padding()
    }
    
    @ViewBuilder
    private func detailItem(icon: String, text: String) -> some View {
        HStack {
            Image(systemName: icon).foregroundColor(.teal).shadow(radius: 0.2)
            Text(text).font(.caption).padding(5).background(Color.teal.opacity(0.2)).cornerRadius(5).shadow(radius: 0.2)
        }
    }
    
    
    private func ingredientsSection(_ mealDetail: MealDetail) -> some View {
        let columns: [GridItem] = Array(repeating: .init(.flexible()), count: 3)
        
        return ZStack(alignment: .topLeading) {
            RoundedRectangle(cornerRadius: 10)
                .fill(Color(.systemBackground)).shadow(radius: 2)
            VStack(alignment: .leading) {
                Text("Ingredients").font(.title2).padding()
                
                LazyVGrid(columns: columns, spacing: 10) {
                    ForEach(0..<mealDetail.ingredients.count, id: \.self) { index in
                        let ingredient = mealDetail.ingredients[index]
                        let ingredientName = ingredient.split(separator: ":")[0].trimmingCharacters(in: .whitespaces)
                        let measure = ingredient.split(separator: ":")[1].trimmingCharacters(in: .whitespaces)
                        let imageName = ingredientName.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                        let imageUrl = URL(string: "https://www.themealdb.com/images/ingredients/\(imageName)-Small.png")
                        
                        VStack {
                            if let imageUrl = imageUrl {
                                AsyncImage(url: imageUrl) { imagePhase in
                                    switch imagePhase {
                                    case .empty: ProgressView()
                                    case .success(let image): image.resizable().aspectRatio(contentMode: .fill).frame(width: 60, height: 50).clipped()
                                    case .failure: Image(systemName: "photo")
                                    @unknown default: EmptyView()
                                    }
                                }
                            }
                            Text(ingredientName)
                                .font(.caption)
                                .lineLimit(1)
                            Text(measure)
                                .font(.caption)
                                .frame(width: 70, height: 20)
                                .background(Color.yellow.opacity(0.2))
                                .cornerRadius(2)
                                .shadow(radius: 0.2)
                        }
                        .padding()
                        .background(Color.teal.opacity(0.3))
                        .cornerRadius(8)
                        .shadow(radius: 0.5)
                        .frame(height: 150)
                    }
                }
            }
        }
    }
    
    @ViewBuilder
    private func instructionsSection(_ mealDetail: MealDetail) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            VStack {
                Text("Instructions")
                    .font(.title2)
                    .fontWeight(.semibold)
                    .foregroundColor(Color.teal)
                    .padding(.bottom, 2)
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.teal)
                    .frame(height: 4)
            }
            .padding([.top, .horizontal])
            
            if let instructions = mealDetail.strInstructions {
                Text(instructions)
                    .font(.body)
                    .foregroundColor(.secondary)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 10).fill(Color(.systemBackground)).shadow(color: Color.gray.opacity(0.3), radius: 5, x: 0, y: 2))
            } else if viewModel.isLoading {
                ProgressView()
                    .scaleEffect(1.5)
                    .padding()
            } else if let errorMessage = viewModel.errorMessage {
                Text("Error: \(errorMessage)")
                    .foregroundColor(.red)
                    .padding()
            }
        }
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(color: Color.teal.opacity(0.5), radius: 5, x: 0, y: 5)
        .padding(.horizontal)
    }

}
