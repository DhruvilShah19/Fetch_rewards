import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            NavigationView {
                HomeView()
                    .navigationBarItems(leading: Image(systemName: "takeoutbag.and.cup.and.straw.fill")
                        .imageScale(.large)
                        .foregroundColor(.teal))
            }
            .tabItem {
                Label("Meals", systemImage: "fork.knife.circle")
            }
            .tag(0)
            NavigationView {
                ProfileView()
            }
            .tabItem {
                Label("Profile", systemImage: "person.circle")
            }
            .tag(1)
        }
        .accentColor(.teal)
    }
}

#Preview {
    ContentView()
}
