//
//  ApiService.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/30/24.
//

import Foundation

struct APIService {
    
    //meal
    func fetchRandomMeal(completion: @escaping (Result<[Meal], Error>) -> Void) {
        guard let url = URL(string: "https://www.themealdb.com/api/json/v1/1/random.php") else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: nil)))
            return
        }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }
                guard let data = data, let mealResponse = try? JSONDecoder().decode(MealResponse.self, from: data) else {
                    completion(.failure(NSError(domain: "", code: -2, userInfo: nil)))
                    return
                }
                completion(.success(mealResponse.meals))
            }
        }.resume()
    }
    
    //category
    func fetchCategories(completion: @escaping (Result<[Category], Error>) -> Void) {
        guard let url = URL(string: "https://www.themealdb.com/api/json/v1/1/categories.php")
        else {
            completion(.failure(NSError(domain: "", code: -1, userInfo: nil)))
            return
        }
        print("Fetching products with URL: \(url)")
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }
                guard let data = data, let categoryResponse = try? JSONDecoder().decode(CategoryResponse.self, from: data) else {
                    completion(.failure(NSError(domain: "", code: -2, userInfo: nil)))
                    return
                }
                completion(.success(categoryResponse.categories))
            }
        }.resume()
    }
    
    //product - category
    func fetchProducts(forCategory categoryName: String, completion: @escaping (Result<[Meal], Error>) -> Void) {
        let encodedCategoryName = categoryName.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
        let url = URL(string: "https://www.themealdb.com/api/json/v1/1/filter.php?c=\(encodedCategoryName)")!
        print("Fetching products with URL: \(url)")
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    completion(.failure(error))
                    return
                }
                
                guard let data = data,
                      let mealsResponse = try? JSONDecoder().decode(MealResponse.self, from: data) else {
                    completion(.failure(NSError(domain: "", code: -2, userInfo: nil)))
                    return
                }
                completion(.success(mealsResponse.meals))
            }
        }.resume()
    }
    
    //meal details - ingridents and everything
    func fetchMealDetails(mealId: String, completion: @escaping (Result<MealDetail, Error>) -> Void) {
        let urlString = "https://www.themealdb.com/api/json/v1/1/lookup.php?i=\(mealId)"
        guard let url = URL(string: urlString) else {
            completion(.failure(NSError(domain: "InvalidURL", code: -1, userInfo: nil)))
            return
        }

        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data, error == nil else {
                completion(.failure(error ?? NSError(domain: "DataError", code: -2, userInfo: nil)))
                return
            }

            do {
                let decoder = JSONDecoder()
                let responseData = try decoder.decode(MealDetailResponse.self, from: data)
                if let mealDetail = responseData.meals.first {
                    DispatchQueue.main.async {
                        completion(.success(mealDetail))
                    }
                } else {
                    completion(.failure(NSError(domain: "MealNotFound", code: -3, userInfo: nil)))
                }
            } catch let decoderError {
                completion(.failure(decoderError))
            }
        }.resume()
    }
}
    
