//
//  HomeViewModel.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/29/24.
//

import Foundation

class MealsViewModel: ObservableObject {
    @Published var meal: Meal?
        @Published var isLoading = false
        @Published var errorMessage: String?

        private var apiService = APIService()

        func fetchRandomMeal() {
            isLoading = true
            errorMessage = nil

            apiService.fetchRandomMeal { [weak self] result in
                DispatchQueue.main.async {
                    self?.isLoading = false
                    switch result {
                    case .success(let meals):
                        self?.meal = meals.first  
                    case .failure(let error):
                        self?.errorMessage = error.localizedDescription
                    }
                }
            }
        }
    }
