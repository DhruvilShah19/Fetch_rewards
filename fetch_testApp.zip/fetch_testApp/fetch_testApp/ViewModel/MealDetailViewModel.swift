//
//  MealDetailViewModel.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/31/24.
//

import Foundation

class MealDetailViewModel: ObservableObject {
    @Published var mealDetail: MealDetail?
    @Published var isLoading = false
    @Published var errorMessage: String?

    private var apiService = APIService()

    func fetchMealDetail(byId mealId: String) {
        isLoading = true
        apiService.fetchMealDetails(mealId: mealId) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let mealDetail):
                    self?.mealDetail = mealDetail
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                }
            }
        }
    }
}
