//
//  CategoryModel.swift
//  fetch_testApp
//
//  Created by Dhruvil Shah on 1/30/24.
//

import Foundation

class CategoriesViewModel: ObservableObject {
    @Published var categories: [Category] = []
    @Published var selectedCategoryMeals: [Meal] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var selectedCategory: String = "Dessert"

    private var apiService = APIService()

    func fetchCategories() {
        isLoading = true
        apiService.fetchCategories { [weak self] result in
            self?.isLoading = false
            switch result {
            case .success(let categories):
                self?.categories = categories
            case .failure(let error):
                self?.errorMessage = error.localizedDescription
            }
        }
    }

    func selectCategory(_ category: String) {
        selectedCategory = category
        fetchMeals(forCategory: category)
    }

    func fetchMeals(forCategory categoryName: String) {
        isLoading = true
        apiService.fetchProducts(forCategory: categoryName) { [weak self] result in
            DispatchQueue.main.async {
                self?.isLoading = false
                switch result {
                case .success(let meals):
                    self?.selectedCategoryMeals = meals
                    print("Fetched meals for category '\(categoryName)': \(meals)")
                case .failure(let error):
                    self?.errorMessage = error.localizedDescription
                    print("Error fetching meals for category '\(categoryName)': \(error)")
                }
            }
        }
    }

}
